import React from 'react';

const SignUp: React.FC = () => {
  return (
    <div>
      <h1>Sign Up</h1>
      <p>Crie uma nova conta.</p>
    </div>
  );
};

export default SignUp;